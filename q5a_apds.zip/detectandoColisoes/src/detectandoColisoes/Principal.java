package detectandoColisoes;


public class Principal {

	public static void main(String[] args) {
		boolean resultadoR;
		Rectangle retangulo = new Rectangle();
		retangulo.lerDimensoes();
		retangulo.calculaColisao();
		resultadoR = retangulo.calculaColisao();
		if(resultadoR == true) System.out.println("1");
		else System.out.println("0");
	}

}
