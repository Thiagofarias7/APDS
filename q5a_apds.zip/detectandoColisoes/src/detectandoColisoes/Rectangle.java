package detectandoColisoes;
import java.util.Scanner;
public class Rectangle {
	public boolean resultado;
	
	public int[][] x = new int[2][2];
	public int[][] y = new int[2][2];
	
	Scanner ler = new Scanner(System.in);
	
	public void lerDimensoes() {
		System.out.println("Digite as coordenadas dos ret�ngulos" + " (X e Y)");
		x[0][0] = ler.nextInt();
		x[0][1] = ler.nextInt();
		x[1][0] = ler.nextInt();
		x[1][1] = ler.nextInt();
		y[0][0] = ler.nextInt();
		y[0][1] = ler.nextInt();
		y[1][0] = ler.nextInt();
		y[1][1] = ler.nextInt();
		//return x;
	}
	
	public boolean calculaColisao(){
		if(x[0][1] < x[1][0] || x[1][1] < x[0][0] || y[0][1] < y[1][0] || y[1][1] < y[0][0] || x[0][0] > x[1][1] || x[1][0] > x[0][1] || y[0][0] > y[1][1] || y[1][0] > y[0][1]) {
			return resultado = false;
		} else {
			return resultado = true;
		}
		
	}
	
}
