package testtxt;

import java.util.Scanner;

public class Principal {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int repeat = 0;
		do {
		boolean resultadoR;
		Rectangle retangulo = new Rectangle();
		int opTec;
		retangulo.ler();
		retangulo.lerDimensoes();
		resultadoR = retangulo.calculaColisao();
		if(resultadoR) System.out.println("1 - N�o houve colis�o");
		else System.out.println("0 - Houve colis�o");
		//Esse foi o melhor c�digo orientado � objeto que eu j� fiz :)
		System.out.println("Deseja sair do programa (1) ou fazer um novo teste? (2)");
		opTec = ler.nextInt();
		if(opTec == 2) repeat = 0; 
		else repeat = 1;
		}while(repeat == 0);
	}
}
