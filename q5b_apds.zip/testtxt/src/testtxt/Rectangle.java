package testtxt;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Rectangle {
	public boolean resultado;
	public int[][] x = new int[2][2];
	public int[][] y = new int[2][2];
	public String[] values = new String[8];
	int op = 0;
	
	Scanner ler = new Scanner(System.in);
	
	public void ler() {
		System.out.printf("Informe o nome de arquivo texto:\n");
	    String nome = ler.nextLine();
		
		try {
	      FileReader arq = new FileReader(nome);
	      BufferedReader lerArq = new BufferedReader(arq);
	      String linha = lerArq.readLine(); 
	      
	      while (linha != null) {
	      	String[] resultado = linha.split(" ");
	      	linha = lerArq.readLine();
	        for(String valor:resultado){
	        	System.out.println("\n"+valor);
	        	values[op] = valor;
	        	op++;
	        }
	      }
	      arq.close();
	    } catch (IOException e) {
	        System.err.printf("Erro na abertura do arquivo: %s.\n",
	          e.getMessage());
	    }
	}
	    
	   public void lerDimensoes(){
		   int[] value = new int[8];
	        for (int i = 0; i < values.length; i++) {
	            value[i] = Integer.parseInt(values[i]);
	        }
			x[0][0] = value[0];
			x[0][1] = value[1];
			x[1][0] = value[2];
			x[1][1] = value[3];
			y[0][0] = value[4];
			y[0][1] = value[5];
			y[1][0] = value[6];
			y[1][1] = value[7];
			
	    }
	    
	   public boolean calculaColisao(){
		if(x[0][1] < x[1][0] || x[1][1] < x[0][0] || y[0][1] < y[1][0] || y[1][1] < y[0][0] || x[0][0] > x[1][1] || x[1][0] > x[0][1] || y[0][0] > y[1][1] || y[1][0] > y[0][1]) {
			return resultado = false;
		} else {
			return resultado = true;
		}
	}
	    

}
