package apds_q4;

public class Cozinha {
	private PortaCozinha Porta;
	private boolean Americana;
	private float MetragemQuadrada;
	
	public void Porta() {
		
	}
	public void MetragemQuadrada() {
		
	}
	public void Americana() {
		
	}
	
}
