package apds_q4;

public class Porta {
	private String Cor;
	private float Largura;
	private float Altura;
	private double Peso;
	
	public void Abrir() {
		
	}
	public void Fechar() {
		
	}
	public void Cor() {
		
	}
	public void Largura() {
		
	}
	public void Altura() {
		
	}
	public void Peso () {
		
	}
	
	
}
