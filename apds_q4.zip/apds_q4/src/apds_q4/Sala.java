package apds_q4;

public class Sala {
	private PortaSala PortaEntrada;
	private float MetragemQuadrada;
	private Porta PortaAuxiliar;
	
	public void MetragemQuadrada() {
		
	}
	public void PortaEntrada() {
		
	}
	public void PortaAuxiliar() {
		
	}
}
