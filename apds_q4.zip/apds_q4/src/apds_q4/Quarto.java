package apds_q4;

public class Quarto {
	private PortaQuarto Porta;
	private boolean Banheiro;
	private float MetragemQuadrada;
	
	public void Porta() {
		
	}
	public void MetragemQuadrada() {
		
	}
	public void Banheiro() {
		
	}
}
