package apds_q4;

public class PortaCozinha extends Porta {
	public void abrir() {
		
	}
	public void fechar() {
		
	}
	
}
