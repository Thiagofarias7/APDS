package apds_q4;

public class PortaSala extends Porta {
	public void Abrir() {
		
	}
	public void Fechar() {
		
	}
}
