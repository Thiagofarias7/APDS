package apds_q4;

public class PortaQuarto extends Porta {
	public void Abrir() {
		
	}
	public void Fechar() {
		
	}
	
}
