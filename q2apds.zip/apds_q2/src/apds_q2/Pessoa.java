package apds_q2;
import java.text.SimpleDateFormat;

public class Pessoa {
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	
	public String nome;
	public String dataComeco;
	public String dataFim;
	public int qtdEmpresas;
	public String[] empresasTrabalhadas;
	
	
	public Pessoa(String nome, String dataComeco, String dataFim, int qtdEmpresas,
			String... empresasTrabalhadas) {
		super();
		this.nome = nome;
		this.dataComeco = dataComeco;
		this.dataFim = dataFim;
		this.qtdEmpresas = qtdEmpresas;
		this.empresasTrabalhadas = empresasTrabalhadas;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getDataComeco() {
		return dataComeco;
	}


	public void setDataComeco(String dataComeco) {
		this.dataComeco = dataComeco;
	}


	public String getDataFim() {
		return dataFim;
	}


	public void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}


	public int getQtdEmpresas() {
		return qtdEmpresas;
	}


	public void setQtdEmpresas(int qtdEmpresas) {
		this.qtdEmpresas = qtdEmpresas;
	}


	public String[] getEmpresasTrabalhadas() {
		return empresasTrabalhadas;
	}


	public void setEmpresasTrabalhadas(String[] empresasTrabalhadas) {
		this.empresasTrabalhadas = empresasTrabalhadas;
	}



	
}
